import * as Constants from "../../../../../actions/usercontainers/common/merchantadd/merchantaddstep5/constants";
import * as AppConstants from "../../../../../../utilities/constants";
// Define initial states.
const initialState = {
  task: '',
  loading: false,
  navigationParams: {},
  merchantAddStep5: {},
};

const merchantAddStep5Reducer = (state = initialState, action) => {
  //console.log("Merchant Add Step 1 Action", action);
  switch (action.type) {
    case Constants.MOVE_TO_URL_ACTION:
      return { ...state, task: action.type, moveToUrl: action.url, navigationParams: action.params };
      case Constants.PERFORM_RETURN_ACTION:
        return { ...state, task:  Constants.MOVE_TO_URL_ACTION, moveToUrl: AppConstants.MERCHANT_ADD_STEP_4_PATH };
      case Constants.SUBMIT_MERCHANT_ACTION:
        return { ...state, task:  Constants.MOVE_TO_URL_ACTION, moveToUrl: AppConstants.MERCHANT_ADD_STEP_6_PATH };
      case Constants.HANDLE_ITEM_CHANGE_ACTION:
      let items = state.merchantAddStep5;
      if(typeof action.checked !== "undefined"){
        items[action.theName] = action.checked? action.theValue: 0; 
      }else {
        items[action.theName] = action.theValue.toUpperCase(); 
      }
      return { ...state, merchantAddStep5:  items};

    case Constants.RESET_TASK_ACTION:
      return { ...state, task: '', loading: false };
    default:
      return state;
  }
};

export default  merchantAddStep5Reducer;