export const DEFAULT_ACTION = 'app/MerchantSearch/DEFAULT_ACTION';
export const DISPLAY_WARNING_ACTION = 'app/MerchantSearch/DISPLAY_WARNING_ACTION';
export const MOVE_TO_URL_ACTION = 'app/MerchantSearch/MOVE_TO_URL_ACTION';

export const HANDLE_ITEM_CHANGE_ACTION = 'app/MerchantSearch/HANDLE_ITEM_CHANGE_ACTION';
export const RECEIVED_MERCHANT_SEARCH_DATA_ERROR = 'app/MerchantSearch/RECEIVED_MERCHANT_SEARCH_DATA_ERROR';
export const RECEIVED_MERCHANT_SEARCH_DATA_ACTION = 'app/MerchantSearch/RECEIVED_MERCHANT_SEARCH_DATA_ACTION';
export const VIEW_MERCHANT_ACTION  = 'app/MerchantSearch/VIEW_MERCHANT_ACTION';

export const GET_MERCHANT_SEARCH_DATA = 'app/MerchantSearch/GET_MERCHANT_SEARCH_DATA';
export const RESET_TASK_ACTION = 'app/MerchantSearch/RESET_TASK_ACTION';

export const REGISTER_ACTION = 'app/MerchantSearch/REGISTER_ACLOGIN_ACTIONTION';
export const CHANGE_PAGE_ACTION = 'app/MerchantSearch/CHANGE_PAGE_ACTION';