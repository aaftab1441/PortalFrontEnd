import * as Constants from './constants';

 
 
export function handleItemChange(theName, theValue, checked) { return { type: Constants.HANDLE_ITEM_CHANGE_ACTION , theName, theValue, checked }; }
export function performSubmitAction(data, user, lists){ return {type: Constants.SUBMIT_MERCHANT_ACTION, data, user, lists}}

export function performReturnAction() { return {type: Constants.PERFORM_RETURN_ACTION }}
export function resetTaskAction() { return {type: Constants.RESET_TASK_ACTION }}
 
export function moveToUrlAction(url, params){ return {type: Constants.MOVE_TO_URL_ACTION, url, params} }


export default {
  handleItemChange,
};
