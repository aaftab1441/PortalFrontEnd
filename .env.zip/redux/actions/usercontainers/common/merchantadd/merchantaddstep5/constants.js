/*
 *
 * MerchantAddStep2 constants
 *
 */

export const DEFAULT_ACTION = 'app/MerchantAddStep5/DEFAULT_ACTION';
export const DISPLAY_WARNING_ACTION = 'app/MerchantAddStep5/DISPLAY_WARNING_ACTION';
export const MOVE_TO_URL_ACTION = 'app/MerchantAddStep5/MOVE_TO_URL_ACTION';

export const HANDLE_ITEM_CHANGE_ACTION = 'app/MerchantAddStep5/HANDLE_ITEM_CHANGE_ACTION';
export const PERFORM_RETURN_ACTION = 'app/MerchantAddStep5/PERFORM_RETURN_ACTION';
export const RECEIVED_MERCHANT_SEARCH_DATA_ACTION = 'app/MerchantAddStep5/RECEIVED_MERCHANT_SEARCH_DATA_ACTION';
export const VIEW_MERCHANT_ACTION  = 'app/MerchantAddStep5/VIEW_MERCHANT_ACTION';

export const SUBMIT_MERCHANT_ACTION = 'app/MerchantAddStep5/SUBMIT_MERCHANT_ACTION';
export const RESET_TASK_ACTION = 'app/MerchantAddStep5/RESET_TASK_ACTION';

export const REGISTER_ACTION = 'app/MerchantAddStep5/REGISTER_ACLOGIN_ACTIONTION';
export const WARNING_BACK_ACTION = 'app/MerchantAddStep5/WARNING_BACK_ACTION';








