/*
 *
 * MerchantAddStep2 constants
 *
 */

export const DEFAULT_ACTION = 'app/MerchantAddStep2/DEFAULT_ACTION';
export const MOVE_TO_URL_ACTION = 'app/MerchantAddStep2/MOVE_TO_URL_ACTION';

export const HANDLE_ITEM_CHANGE_ACTION = 'app/MerchantAddStep2/HANDLE_ITEM_CHANGE_ACTION';
export const PERFORM_RETURN_ACTION = 'app/MerchantAddStep2/PERFORM_RETURN_ACTION';

export const RECEIVED_FEES_ACTION = 'app/MerchantAddStep2/RECEIVED_FEES_ACTION';
export const GET_FEES_ACTION  = 'app/MerchantAddStep2/GET_FEES_ACTION';
export const RECEIVED_FEES_ERROR = 'app/MerchantAddStep2/RECEIVED_FEES_ERROR';

export const SUBMIT_MERCHANT_ACTION = 'app/MerchantAddStep2/SUBMIT_MERCHANT_ACTION';
export const RESET_TASK_ACTION = 'app/MerchantAddStep2/RESET_TASK_ACTION';

export const ADD_FEE_ACTION = 'app/MerchantAddStep2/ADD_FEE_ACTION';
export const REMOVE_FEE_ACTION = 'app/MerchantAddStep2/REMOVE_FEE_ACTION';








