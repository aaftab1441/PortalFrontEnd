import * as Constants from './constants';

 
 
export function handleItemChange(theName, theValue, checked) { return { type: Constants.HANDLE_ITEM_CHANGE_ACTION , theName, theValue, checked }; }
export function performSubmitAction(data, user, lists){ return {type: Constants.SUBMIT_MERCHANT_ACTION, data, user, lists}}

export function resetTaskAction() { return {type: Constants.RESET_TASK_ACTION }}
export function receivedFeesAction(data){ return {type: Constants.RECEIVED_FEES_ACTION, data}}
export function receivedFeesError(err, data){ return {type: Constants.RECEIVED_FEES_ERROR, err, data}}

export function performReturnAction() { return {type: Constants.PERFORM_RETURN_ACTION }}
export function getFeesAction() { return {type: Constants.GET_FEES_ACTION }}

export function addFeeAction(theFee) { return {type: Constants.ADD_FEE_ACTION, theFee }}
export function removeFeeAction(theFee) { return {type: Constants.REMOVE_FEE_ACTION, theFee }}

export function moveToUrlAction(url, params){ return {type: Constants.MOVE_TO_URL_ACTION, url, params} }

export default {
  handleItemChange,
};
