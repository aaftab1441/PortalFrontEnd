/*
 *
 * MerchantAddStep3 constants
 *
 */

export const DEFAULT_ACTION = 'app/MerchantAddStep3/DEFAULT_ACTION';
export const ADD_FEE_ACTION = 'app/MerchantAddStep3/ADD_FEE_ACTION';
export const MOVE_TO_URL_ACTION = 'app/MerchantAddStep3/MOVE_TO_URL_ACTION';

export const HANDLE_ITEM_CHANGE_ACTION = 'app/MerchantAddStep3/HANDLE_ITEM_CHANGE_ACTION';
export const REMOVE_FEE_ACTION = 'app/MerchantAddStep3/REMOVE_FEE_ACTION';
export const RECEIVED_FEES_ACTION = 'app/MerchantAddStep3/RECEIVED_FEES_ACTION';
export const RESET_TASK_ACTION = 'app/MerchantAddStep3/RESET_TASK_ACTION';

export const RECEIVED_FEES_ERROR = 'app/MerchantAddStep3/RECEIVED_FEES_ERROR';
export const GET_FEES_ACTION = 'app/MerchantAddStep3/GET_FEES_ACTION';
export const SUBMIT_MERCHANT_ACTION = 'app/MerchantAddStep3/SUBMIT_MERCHANT_ACTION';
export const PERFORM_RETURN_ACTION = 'app/MerchantAddStep3/PERFORM_RETURN_ACTION';










