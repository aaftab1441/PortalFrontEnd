
export const DEFAULT_ACTION = 'app/GenericMerchantList/DEFAULT_ACTION';
export const DISPLAY_WARNING_ACTION = 'app/GenericMerchantList/DISPLAY_WARNING_ACTION';
export const MOVE_TO_URL_ACTION = 'app/GenericMerchantList/MOVE_TO_URL_ACTION';

export const SUBMIT_LOGIN_ACTION = 'app/GenericMerchantList/SUBMIT_LOGIN_ACTION';
export const RECEIVED_DATA_ERROR = 'app/GenericMerchantList/RECEIVED_DATA_ERROR';
export const RECEIVED_DATA_ACTION = 'app/GenericMerchantList/RECEIVED_DATA_ACTION';
export const VIEW_MERCHANT_ACTION  = 'app/GenericMerchantList/VIEW_MERCHANT_ACTION';

export const GET_DATA = 'app/GenericMerchantList/GET_DATA';
export const RESET_TASK_ACTION = 'app/GenericMerchantList/RESET_TASK_ACTION';

export const GET_MERCHANTS_ACTION = 'app/GenericMerchantList/GET_MERCHANTS_ACTION';
export const HANDLE_ITEM_CHANGE_ACTION = 'app/GenericMerchantList/HANDLE_ITEM_CHANGE_ACTION';



