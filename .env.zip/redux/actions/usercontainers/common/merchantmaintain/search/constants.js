export const DEFAULT_ACTION = 'app/Common/MerchantMaintain/Search/DEFAULT_ACTION';
export const CHANGE_PAGE_ACTION = 'app/Common/MerchantMaintain/Search/CHANGE_PAGE_ACTION';
export const MOVE_TO_URL_ACTION = 'app/Common/MerchantMaintain/Search/MOVE_TO_URL_ACTION';

export const HANDLE_ITEM_CHANGE_ACTION = 'app/Common/MerchantMaintain/Search/HANDLE_ITEM_CHANGE_ACTION';
export const RECEIVED_MERCHANT_SEARCH_DATA_ERROR = 'app/Common/MerchantMaintain/Search/RECEIVED_MERCHANT_SEARCH_DATA_ERROR';
export const RECEIVED_MERCHANT_SEARCH_DATA_ACTION = 'app/Common/MerchantMaintain/Search/RECEIVED_MERCHANT_SEARCH_DATA_ACTION';
export const VIEW_MERCHANT_ACTION  = 'app/Common/MerchantMaintain/Search/VIEW_MERCHANT_ACTION';

export const GET_MERCHANT_SEARCH_DATA = 'app/Common/MerchantMaintain/Search/GET_MERCHANT_SEARCH_DATA';
export const RESET_TASK_ACTION = 'app/Common/MerchantMaintain/Search/RESET_TASK_ACTION';
 