/*
 *
 * IsoDashboard constants
 *
 */

export const DEFAULT_ACTION = 'app/IsoDashboard/DEFAULT_ACTION';
export const DISPLAY_WARNING_ACTION = 'app/IsoDashboard/DISPLAY_WARNING_ACTION';
export const MOVE_TO_URL_ACTION = 'app/IsoDashboard/MOVE_TO_URL_ACTION';

export const SUBMIT_LOGIN_ACTION = 'app/IsoDashboard/SUBMIT_LOGIN_ACTION';
export const RECEIVED_DASHBOARD_DATA_ERROR = 'app/IsoDashboard/RECEIVED_DASHBOARD_DATA_ERROR';
export const RECEIVED_DASHBOARD_DATA_ACTION = 'app/IsoDashboard/RECEIVED_DASHBOARD_DATA_ACTION';

export const GET_DASHBOARD_DATA = 'app/IsoDashboard/GET_DASHBOARD_DATA';
export const RESET_TASK_ACTION = 'app/IsoDashboard/RESET_TASK_ACTION';

export const REGISTER_ACTION = 'app/IsoDashboard/REGISTER_ACLOGIN_ACTIONTION';
export const WARNING_BACK_ACTION = 'app/IsoDashboard/WARNING_BACK_ACTION';
export const EXIT_ACTION = 'app/IsoDashboard/EXIT_ACTION';
export const LOGIN_ACTION = 'app/IsoDashboard/LOGIN_ACTION';
export const FORGOT_PASSWORD_ACTION = 'app/IsoDashboard/FORGOT_PASSWORD_ACTION';
export const REGISTER_VERIFY_ACTION = 'app/IsoDashboard/REGISTER_VERIFY_ACTION';






