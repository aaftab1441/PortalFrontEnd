/*
 *
 * IsoList constants
 *
 */

export const DEFAULT_ACTION = 'app/IsoList/DEFAULT_ACTION';
export const DISPLAY_WARNING_ACTION = 'app/IsoList/DISPLAY_WARNING_ACTION';
export const MOVE_TO_URL_ACTION = 'app/IsoList/MOVE_TO_URL_ACTION';

export const SUBMIT_LOGIN_ACTION = 'app/IsoList/SUBMIT_LOGIN_ACTION';
export const RECEIVED_DASHBOARD_DATA_ERROR = 'app/IsoList/RECEIVED_DASHBOARD_DATA_ERROR';
export const RECEIVED_DASHBOARD_DATA_ACTION = 'app/IsoList/RECEIVED_DASHBOARD_DATA_ACTION';

export const GET_DASHBOARD_DATA = 'app/IsoList/GET_DASHBOARD_DATA';
export const RESET_TASK_ACTION = 'app/IsoList/RESET_TASK_ACTION';

export const REGISTER_ACTION = 'app/IsoList/REGISTER_ACLOGIN_ACTIONTION';
export const VIEW_ISO_DETAIL_ACTION = 'app/IsoList/VIEW_ISO_DETAIL_ACTION';
export const EXIT_ACTION = 'app/IsoList/EXIT_ACTION';
export const LOGIN_ACTION = 'app/IsoList/LOGIN_ACTION';
//export const VIEW_ISO_DETAIL_ACTION = 'app/IsoList/FORGOT_PASSWORD_ACTION';
export const REGISTER_VERIFY_ACTION = 'app/IsoList/REGISTER_VERIFY_ACTION';






