module.exports = {
   
	
	images: {
		disableStaticImages: true,
		loader: 'imgix',
	},
}
