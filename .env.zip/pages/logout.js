import Head from "next/head";
import Header from "../components/common/GetHeader";
import Footer from "../components/common/GetFooter";
import styles from "../styles/Home.module.css";
import {Col, Container, Row} from "react-bootstrap";
import React from "react";
//import Button from "../components/common/Button";

export default function Logout(props) {
    return (
        <>
            
        </>
    )
}