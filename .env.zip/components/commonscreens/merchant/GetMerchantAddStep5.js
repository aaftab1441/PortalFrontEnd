import React from 'react';
import PropTypes from 'prop-types';
import { ValidatorForm } from 'react-material-ui-form-validator';
import TextBox from '../../common/TextBox';
import SelectField from '../../common/SelectField';

import * as AppConstants from '../../../utilities/constants';
import * as StringUtils from '../../../utilities/string';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Paper from '@mui/material/Paper';
import DataTable from 'react-data-table-component';
import { Row, Col,Form} from 'react-bootstrap'; 
import { Button } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import { Theme, createStyles, makeStyles } from '@mui/system';
import MenuItem from '@mui/material/MenuItem';
import DatePicker from "react-datepicker";
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
//import Button from '@mui/material/Button';
// import styled from 'styled-components';
 

function GetMerchantAddStep5(props) {
  let stateList = [];
  let count = 0;
  let startCount = 0;

  //const classes = useStyles();
  console.log("Merchant List", props);
  
  let irsTaxList  = [];
  let appMessages = StringUtils.getDisplayMessages(props.messages);
  let yesNoList = []
  let mailingPreferenceList = [];
  let fees = "";
   
  if(props.lists &&  props.lists.STATUS){
	  
	stateList = props.lists.STATES.map(function (anItem, index) {
		return <MenuItem value={anItem.code} key={index}>{anItem.value}</MenuItem>;
	  });
	  
	  yesNoList = props.lists.YES_NO_LIST.map(function (anItem, index) {
		return <MenuItem value={anItem.code} key={index}>{anItem.value}</MenuItem>;
	  });
	}

  return (
		<div>
		  <div className="row">
			<div className="col-lg-12">
			  <div className="card">
				<div className="card-body">
				  <div className="row">
					<div className="col-12" id="search">
						<h4>OWNER INFORMATION</h4>
						<Stepper activeStep={4} alternativeLabel>

							<Step key={'General_Information'}>
								<StepLabel>General Information</StepLabel>
							</Step>
							<Step key={'Fee_Disc'}>
								<StepLabel>Fee/Disc</StepLabel>
							</Step>
							<Step key={'ISO'}>
								<StepLabel>ISO</StepLabel>
							</Step>
							<Step key={'Merchant_Management'}>
								<StepLabel>Merchant Management</StepLabel>
							</Step>
							<Step key={'Merchant_Owner'}>
								<StepLabel>Merchant Owner</StepLabel>
							</Step>
							<Step key={'Document_Upload'}>
								<StepLabel>Document(s) Upload</StepLabel>
							</Step>

						</Stepper>
					<ValidatorForm className="pt-3" onSubmit={(data) => props.doSearch(data, props.user, props.lists)}>
						 
							
						<Row>
							 
							<Col>OWNER 1 INFORMATION</Col>
							<br /><br />
							 
						</Row>
						 
								
						<Form.Group className='col-md-12'> 
							<Row>
								<Col md={3} >
									<label>First Name</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_first_1', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_first_1',
											id: 'mm_owner_first_1',
											placeholder: 'FIRST NAME',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>
								<Col md={3}>
									<label>Middle Initial</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_mi_1', '' )}
										onChange={props.handleItemChange}
										validators={[]}
										errorMessages={[]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_mi_1',
											id: 'mm_owner_mi_1',
											placeholder: 'MIDDLE INITIAL',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>									
								<Col md={3}>
									<label>Last Name</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_last_1', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_last_1',
											id: 'mm_owner_last_1',
											placeholder: 'LAST NAME',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>	
								<Col md={3}>
									<label>Suffix</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_suffix_1', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_suffix_1',
											id: 'mm_owner_suffix_1',
											placeholder: 'SUFFIX',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>								
							</Row>									
						</Form.Group>
						<Form.Group className='col-md-12'>
							<Row>
								<Col md={3} >
									<label>Street</label>
									<TextBox
									value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_addr1_1', '' )}
									onChange={props.handleItemChange}
									validators={['required']}
									errorMessages={["REQUIRED"]}
									variant={'outlined'}
									inputProps={{
										name: 'mm_owner_addr1_1',
										id: 'mm_owner_addr1_1',
										placeholder: 'STREET ADDRESS',
										type: 'text',
										classselector: "h-auto"
									}}
									/>
					
								</Col>
								<Col md={3} >
									<label>City</label>
									<TextBox
									value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_city_1', '' )}
									onChange={props.handleItemChange}
									validators={['required']}
									errorMessages={["REQUIRED"]}
									variant={'outlined'}
									inputProps={{
										name: 'mm_owner_city_1',
										id: 'mm_owner_city_1',
										placeholder: 'CITY',
										type: 'text',
										classselector: "h-auto"
									}}
									/>
					
								</Col>
								<Col md={3}>
									<label>State</label>
									<SelectField
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_state_1', '' )}
										onChange={props.handleItemChange}
										validators={['required']}											
										variant="outlined" size="small"
										errorMessages={['Required']}
										inputProps={{
										name: 'mm_owner_state_1',
										id: 'mm_owner_state_1', 
										}}
									>
										{stateList}
									</SelectField>
										
					
								</Col>	
								<Col md={3} >
									<label>Zip</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_zip_1', '' )}
										onChange={props.handleItemChange}
										validators={['required']}											
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_zip_1',
											id: 'mm_owner_zip_1',
											placeholder: 'ZIP CODE',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
					
								</Col>	
							</Row>
						</Form.Group>
						<Form.Group className='col-md-12'> 
							<Row>
								<Col md={3} >
									<label>Social Security #</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_ssno_1', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_ssno_1',
											id: 'mm_owner_ssno_1',
											placeholder: 'SOCIAL SECURITY NUMBER',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>
								<Col md={3}>
									<label>Birth Date (MM/DD/CCYY)</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_dob_1', '' )}
										onChange={props.handleItemChange}
										validators={[]}
										errorMessages={[]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_dob_1',
											id: 'mm_owner_dob_1',
											placeholder: "DATE OF BIRTH",
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>
								<Col md={3}>
									<label>Driver&apos;s License #</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_dlno_1', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_dlno_1',
											id: 'mm_dlno_1',
											placeholder: "DRIVER'S LICENSE NUMBER",
											type: 'date',
											classselector: "h-auto"
										}}
									/>
								</Col>									
								<Col md={3}>
									<label>Driver&apos;s License State</label>
									<SelectField
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_dlno_state_1', '' )}
										onChange={props.handleItemChange}
										validators={['required']}											
										variant="outlined" size="small"
										errorMessages={['Required']}
										inputProps={{
										name: 'mm_dlno_state_1',
										id: 'mm_dlno_state_1', 
										}}
									>
										{stateList}
									</SelectField>
								</Col>	
							</Row>									
						</Form.Group>
						<Form.Group className='col-md-12'> 
							<Row>
								<Col md={3} >
									<label>Phone Number</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_phone_1', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_phone_1',
											id: 'mm_owner_phone_1',
											placeholder: 'PHONE NUMBER',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>
								<Col md={3}>
									<label>Email</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_contact_dl_no', '' )}
										onChange={props.handleItemChange}
										validators={[]}
										errorMessages={[]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_contact_dl_no',
											id: 'mm_contact_dl_no',
											placeholder: "DRIVER'S LICENSE NUMBER",
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>									
								<Col md={3}>
									<label>Years Owned</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_years_owned_1', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_years_owned_1',
											id: 'mm_years_owned_1',
											placeholder: "YEARS OWNED",
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>
								<Col md={3}>
									<label>Equity Percent</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_perc_1', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_perc_1',
											id: 'mm_owner_perc_1',
											placeholder: "OWNERSHIP PERCENT",
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>	
							</Row>									
						</Form.Group>
						 
					
						<Row>
							 
							<Col>OWNER 2 INFORMATION</Col>
							<br /><br />
							 
						</Row>
						 
								
						<Form.Group className='col-md-12'> 
							<Row>
								<Col md={3} >
									<label>First Name</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_first_2', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_first_2',
											id: 'mm_owner_first_2',
											placeholder: 'FIRST NAME',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>
								<Col md={3}>
									<label>Middle Initial</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_mi_2', '' )}
										onChange={props.handleItemChange}
										validators={[]}
										errorMessages={[]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_mi_2',
											id: 'mm_owner_mi_2',
											placeholder: 'MIDDLE INITIAL',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>									
								<Col md={3}>
									<label>Last Name</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_last_2', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_last_2',
											id: 'mm_owner_last_2',
											placeholder: 'LAST NAME',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>	
								<Col md={3}>
									<label>Suffix</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_suffix_2', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_suffix_2',
											id: 'mm_owner_suffix_2',
											placeholder: 'SUFFIX',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>								
							</Row>									
						</Form.Group>
						<Form.Group className='col-md-12'>
							<Row>
								<Col md={3} >
									<label>Street</label>
									<TextBox
									value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_addr1_2', '' )}
									onChange={props.handleItemChange}
									validators={['required']}
									errorMessages={["REQUIRED"]}
									variant={'outlined'}
									inputProps={{
										name: 'mm_owner_addr1_2',
										id: 'mm_owner_addr1_2',
										placeholder: 'STREET ADDRESS',
										type: 'text',
										classselector: "h-auto"
									}}
									/>
					
								</Col>
								<Col md={3} >
									<label>City</label>
									<TextBox
									value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_city_2', '' )}
									onChange={props.handleItemChange}
									validators={['required']}
									errorMessages={["REQUIRED"]}
									variant={'outlined'}
									inputProps={{
										name: 'mm_owner_city_2',
										id: 'mm_owner_city_2',
										placeholder: 'CITY',
										type: 'text',
										classselector: "h-auto"
									}}
									/>
					
								</Col>
								<Col md={3}>
									<label>State</label>
									<SelectField
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_state_2', '' )}
										onChange={props.handleItemChange}
										validators={['required']}											
										variant="outlined" size="small"
										errorMessages={['Required']}
										inputProps={{
										name: 'mm_owner_state_2',
										id: 'mm_owner_state_2', 
										}}
									>
										{stateList}
									</SelectField>
										
					
								</Col>	
								<Col md={3} >
									<label>Zip</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_zip_2', '' )}
										onChange={props.handleItemChange}
										validators={['required']}											
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_zip_2',
											id: 'mm_owner_zip_2',
											placeholder: 'ZIP CODE',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
					
								</Col>	
							</Row>
						</Form.Group>
						<Form.Group className='col-md-12'> 
							<Row>
								<Col md={3} >
									<label>Social Security #</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_ssno_2', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_ssno_2',
											id: 'mm_owner_ssno_2',
											placeholder: 'SOCIAL SECURITY NUMBER',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>
								<Col md={3}>
									<label>Birth Date (MM/DD/CCYY)</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_owner_dob_2', '' )}
										onChange={props.handleItemChange}
										validators={[]}
										errorMessages={[]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_dob_2',
											id: 'mm_owner_dob_2',
											placeholder: "DATE OF BIRTH",
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>
								<Col md={3}>
									<label>Driver&apos;s License #</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_dlno_2', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_dlno_2',
											id: 'mm_dlno_2',
											placeholder: "DRIVER'S LICENSE NUMBER",
											type: 'date',
											classselector: "h-auto"
										}}
									/>
								</Col>									
								<Col md={3}>
									<label>Driver&apos;s License State</label>
									<SelectField
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_dlno_state_2', '' )}
										onChange={props.handleItemChange}
										validators={['required']}											
										variant="outlined" size="small"
										errorMessages={['Required']}
										inputProps={{
										name: 'mm_dlno_state_2',
										id: 'mm_dlno_state_2', 
										}}
									>
										{stateList}
									</SelectField>
								</Col>	
							</Row>									
						</Form.Group>
						<Form.Group className='col-md-12'> 
							<Row>
								<Col md={3} >
									<label>Phone Number</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_phone_2', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_phone_2',
											id: 'mm_owner_phone_2',
											placeholder: 'PHONE NUMBER',
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>
								<Col md={3}>
									<label>Email</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_contact_dl_no', '' )}
										onChange={props.handleItemChange}
										validators={[]}
										errorMessages={[]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_contact_dl_no',
											id: 'mm_contact_dl_no',
											placeholder: "DRIVER'S LICENSE NUMBER",
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>									
								<Col md={3}>
									<label>Years Owned</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_years_owned_2', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_years_owned_2',
											id: 'mm_years_owned_2',
											placeholder: "YEARS OWNED",
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>
								<Col md={3}>
									<label>Equity Percent</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Extra, 'mm_owner_perc_2', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_owner_perc_2',
											id: 'mm_owner_perc_2',
											placeholder: "OWNERSHIP PERCENT",
											type: 'text',
											classselector: "h-auto"
										}}
									/>
								</Col>	
							</Row>									
						</Form.Group>
						 
						<div className="row">
							<Col md="3">
								<Button variant="contained" color="primary" type="button" onClick={() => props.performReturn()} className="col-md-12"> Return </Button>
							</Col>
							<Col md="6">&nbsp;</Col>
							<Col md="3">
								<Button variant="contained" color="primary" type="button"  onClick={() => props.performSubmit()} className="col-md-12"> Save &amp; Continue </Button>
							</Col>
							
						</div>
					</ValidatorForm>
					
						
					
				</div>
					
				
					
					 
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</div>
  );
}

GetMerchantAddStep5.propTypes = {
  displayWarning: PropTypes.func,
};

export default GetMerchantAddStep5;

