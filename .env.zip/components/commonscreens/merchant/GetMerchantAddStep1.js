import React from 'react';
import PropTypes from 'prop-types';
import { ValidatorForm } from 'react-material-ui-form-validator';
import TextBox from '../../common/TextBox';
import SelectField from '../../common/SelectField';

import * as AppConstants from '../../../utilities/constants';
import * as StringUtils from '../../../utilities/string';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Paper from '@mui/material/Paper';
import DataTable from 'react-data-table-component';
import { Row, Col,Form} from 'react-bootstrap'; 
import { Button } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import { Theme, createStyles, makeStyles } from '@mui/system';
import MenuItem from '@mui/material/MenuItem';
import DatePicker from "react-datepicker";
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
//import Button from '@mui/material/Button';
// import styled from 'styled-components';
 

function GetMerchantAddStep1(props) {
  let stateList = [];
  let count = 0;
  let startCount = 0;

  //const classes = useStyles();
  console.log("Merchant List", props);
  let irsTaxList  = [];
  let appMessages = StringUtils.getDisplayMessages(props.messages);
  let statusList  = [], yesNoList = [], sicList = [], merchantTypeList = [];
  let ownershipList = []
  let mailingPreferenceList = [];
  if(props.lists &&  props.lists.STATUS){
	statusList = props.lists.STATUS.map(function (anItem, index) {
		return <MenuItem value={anItem.code} key={index}>{anItem.value}</MenuItem>;
	  });
	  
	  stateList = props.lists.STATES.map(function (anItem, index) {
		return <MenuItem value={anItem.code} key={index}>{anItem.value}</MenuItem>;
	  });
	  irsTaxList = props.lists.IRS_TAX_ID_TYPE.map(function (anItem, index) {
		return <MenuItem value={anItem.code} key={index}>{anItem.value}</MenuItem>;
	  });
	  mailingPreferenceList = props.lists.MAILING_ADDRESS_PREFERENCE.map(function (anItem, index) {
		return <MenuItem value={anItem.code} key={index}>{anItem.value}</MenuItem>;
	  });
	  yesNoList = props.lists.YES_NO_LIST.map(function (anItem, index) {
		return <MenuItem value={anItem.code} key={index}>{anItem.value}</MenuItem>;
	  });
	  merchantTypeList = props.lists.MERCHANT_TYPE_LIST.map(function (anItem, index) {
		return <MenuItem value={anItem.code} key={index}>{anItem.value}</MenuItem>;
	  });
	  ownershipList = props.lists.OWNERSHIP_TYPE_LIST.map(function (anItem, index) {
		return <MenuItem value={anItem.code} key={index}>{anItem.value}</MenuItem>;
	  });
	  
	  sicList = props.lists.SIC_CODES;
	  
	}

  return (
		<div>
		  <div className="row">
			<div className="col-lg-12">
			  <div className="card">
				<div className="card-body">
				  <div className="row">
					<div className="col-12" id="search">
						<h4>Merchant Add</h4>
						<Stepper activeStep={0} alternativeLabel>

							<Step key={'General_Information'}>
								<StepLabel>General Information</StepLabel>
							</Step>
							<Step key={'Fee_Disc'}>
								<StepLabel>Fee/Disc</StepLabel>
							</Step>
							<Step key={'ISO'}>
								<StepLabel>ISO</StepLabel>
							</Step>
							<Step key={'Merchant_Management'}>
								<StepLabel>Merchant Management</StepLabel>
							</Step>
							<Step key={'Merchant_Owner'}>
								<StepLabel>Merchant Owner</StepLabel>
							</Step>
							<Step key={'Document_Upload'}>
								<StepLabel>Document(s) Upload</StepLabel>
							</Step>

						</Stepper>
					<ValidatorForm className="pt-3" onSubmit={(data) => props.performSubmit(data, props.user, props.lists)}>
						 
							
						<Row>
							 
							<Col>DBA MERCHANT/TRADE INFO</Col>
							<br /><br />
							 
						</Row>
						
								
						<Row>
							 <Form.Group className='col-md-12'>
								 <Row>
									<Col md={5} >
										<label >DBA or Trade Name</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_dba_name', '' )}
											onChange={props.handleItemChange}
											validators={['required']}											
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_dba_name',
												id: 'mm_dba_name',
												placeholder: 'DBA OR TRADE NAME',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>
									<Col md={5} >
										<label >Merchant Number</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_cust_no', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_cust_no',
												id: 'mm_cust_no',
												placeholder: 'Merchant Number',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>
									<Col md={2} >
										<label >Status</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_status_code', '' )}
											onChange={props.handleItemChange}
											validators={['required']}											 
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'mm_status_code',
											id: 'mm_status_code',
											}}
										>
											{statusList}
										</SelectField>
						
									</Col>
									
								</Row>
							</Form.Group>
								 
							 
							<Form.Group className='col-md-12'>
								<Row>
									<Col md={5} >
										<label>City</label>
										<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_location_city', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_location_city',
											id: 'mm_location_city',
											placeholder: 'CITY',
											type: 'text',
											classselector: "h-auto"
										}}
										/>
						
									</Col>
									<Col md={4}>
										<label>State</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_location_zip', '' )}
											onChange={props.handleItemChange}
											validators={['required']}											
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'mm_location_state',
											id: 'mm_location_state',
											}}
										>
											{stateList}
										</SelectField>
											
						
									</Col>	
									<Col md={3} >
										<label>Zip</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_location_zip', '' )}
											onChange={props.handleItemChange}
											validators={['required']}											
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_location_zip',
												id: 'mm_location_zip',
												placeholder: 'ZIPCODE',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>	
								</Row>
							</Form.Group>
							<Form.Group className='col-md-12'>
								<Row>
									<Col md={6} >
									<label>Date of Incorporation</label>
										
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_bus_open_date', '' )}
											onChange={props.handleItemChange}
											validators={['required']}											
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_bus_open_date',
												id: 'mm_bus_open_date',
												placeholder: 'DATE OF INCORPORATION',
												type: 'date',
												classselector: "h-auto"
											}}
										/>							
									</Col>
										
									<Col md={6}>
										<label>State of Incorporation</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_incorp_state', '' )}
											onChange={props.handleItemChange}
											validators={['required']}												
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'mm_incorp_state',
											id: 'mm_incorp_state',
											}}
										>
											{stateList}
										</SelectField>
						
									</Col>	
										
								</Row>
							</Form.Group>	
							<Form.Group className='col-md-12'>
								<Row>
									<Col md={6} >
										<label>Contact First Name</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_contact_first_name', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_contact_first_name',
												id: 'mm_contact_first_name',
												placeholder: 'CONTACT FIRST NAME',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>	
									<Col md={6} >
										<label>Contact Last Name</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_contact_last_name', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_contact_last_name',
												id: 'mm_contact_last_name',
												placeholder: 'CONTACT LAST NAME',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>
								</Row>
							</Form.Group>
							<Form.Group className='col-md-12'>
								<Row>
									<Col md={3} >
										<label>Contact Phone</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_contact_phone', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_contact_phone',
												id: 'mm_contact_phone',
												placeholder: 'CONTACT PHONE',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>	
									<Col md={3} >
										<label>Contact Fax</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_contact_fax', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_contact_fax',
												id: 'mm_contact_fax',
												placeholder: 'CONTACT FAX',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>	
									<Col md={3} >
										<label>Business Phone</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_business_phone', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_business_phone',
												id: 'mm_business_phone',
												placeholder: 'BUSINESS PHONE',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>	
									<Col md={3} >
										<label>Business Fax</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_business_fax', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_business_fax',
												id: 'mm_business_fax',
												placeholder: 'BUSINESS FAX',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>										
								</Row>
							</Form.Group>
							<Form.Group className='col-md-12'>
								<Row>
									<Col md={3} >
										<label>Business Email</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_business_email', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_business_email',
												id: 'mm_business_email',
												placeholder: 'BUSINESS EMAIL',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>	
									<Col md={3} >
										<label>Business Website Address</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_business_url', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_business_url',
												id: 'mm_business_url',
												placeholder: 'BUSINESS WEBSITE ADDRESS',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>	
									<Col md={3} >
										<label>Years in Business</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_ownership_length', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_ownership_length',
												id: 'mm_ownership_length',
												placeholder: 'YEARS IN BUSINESS',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>
									<Col md={3} >
										<label>Number of Locations</label>
										<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_location_count', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_location_count',
											id: 'mm_location_count',
											placeholder: 'NUMBER OF LOCATIONS',
											type: 'text',
											classselector: "h-auto"
										}}
										/>
						
									</Col>										
								</Row>	
							</Form.Group>
							<Form.Group className='col-md-12'>
								<Row>
									<Col md={6} >
										<label>Social Security Number (SSN)/Employer ID #</label>
										<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_irs_tax_id', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_irs_tax_id',
											id: 'mm_irs_tax_id',
											placeholder: 'SSN/EIN',
											type: 'text',
											classselector: "h-auto"
										}}
										/>
						
									</Col>
									<Col md={6} >
										<label>Employer Identification Number (EIN)</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_irs_tax_id_type', '' )}
											onChange={props.handleItemChange}
											validators={['required']}												
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'mm_irs_tax_id_type',
											id: 'mm_irs_tax_id_type',
											}}
										>
											{irsTaxList}
										</SelectField>
											
									</Col>
								</Row>
							</Form.Group>
							<Form.Group className='col-md-12'>
								<Row>
									<Col md={3} >
										<label>Minimum Monthly Volume $</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_monthly_vol', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_monthly_vol',
												id: 'mm_monthly_vol',
												placeholder: 'MINIMUM MONTHLY VOLUME',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
									</Col>	
									<Col md={3}>
										<label>Average Ticket $</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_avg_ticket', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_avg_ticket',
												id: 'mm_avg_ticket',
												placeholder: 'AVERAGE TICKET',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
									</Col>	
									<Col md={3}>
										<label>High Ticket $</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_high_ticket', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_high_ticket',
												id: 'mm_high_ticket',
												placeholder: 'HIGH TICKET',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
									</Col>	
									<Col md={3}>
										<label>Maximum Monthly Volume $</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_high_month_volume', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_high_month_volume',
												id: 'mm_high_month_volume',
												placeholder: 'MAXIMUM MONTHLY VOLUME',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
									</Col>
								</Row>
							</Form.Group>
							<Form.Group className='col-md-12'> 
								<Row>
									<Col md={3} >
										<label>Annual Volume $</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Extra, 'me_annual_volume', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'me_annual_volume',
												id: 'me_annual_volume',
												placeholder: 'ANNUAL VOLUME',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
									</Col>
									<Col md={3} >
										<label>Previous Processor</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'me_current_prev_processor', '' )}
											onChange={props.handleItemChange}
											validators={[]}
											errorMessages={[]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'me_current_prev_processor',
												id: 'me_current_prev_processor',
												placeholder: 'PREVIOUS PROCESSOR',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
									</Col>
									<Col md={3} >
										<label>Reason for Leaving</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'me_termination_reason', '' )}
											onChange={props.handleItemChange}
											validators={[]}
											errorMessages={[]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'me_termination_reason',
												id: 'me_termination_reason',
												placeholder: 'REASON FOR LEAVING',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
									</Col>	
									
									<Col md={3} >
										<label>Mailing Address Preference</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_mailing_preference', '' )}
											onChange={props.handleItemChange}
											validators={['required']}												
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'mm_mailing_preference',
											id: 'mm_mailing_preference',
											}}
										>
											{mailingPreferenceList}
										</SelectField>
									</Col>	
								</Row>									
							</Form.Group>		 
							<Form.Group className="col-md-12">
								<Row>
									<Col md={3} >
										<label>Types of Goods/Services</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_good_services_delivered', '' )}
											onChange={props.handleItemChange}
											validators={[]}
											errorMessages={[]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_good_services_delivered',
												id: 'mm_good_services_delivered',
												placeholder: 'TYPES OF GOODS/SERVICES',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
									</Col>
									<Col md={3}>
										<label>Next Day Funding</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_one_day_ach', '' )}
											onChange={props.handleItemChange}
											validators={['required']}												
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'mm_one_day_ach',
											id: 'mm_one_day_ach',
											}}
										>
											{yesNoList}
										</SelectField>
									</Col>
									<Col md={3}>
										<label>MSCC/Sic Code</label>
										<Autocomplete
											id="mm_irs_sic_code"
											getOptionSelected={(option, value) => option.sic_code === StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_irs_sic_code', '' ) }
											options={sicList}
											className={'col-md-12'}
											getOptionLabel={(option) => option.sic_code + " - " + option.sic_desc}
											style={{ width: '100%' }, {padding: '0px'}}
											renderInput={(params) => <TextField {...params} variant="outlined"   />}
										/>
											
									</Col>
									<Col md={3}>
										<label>Merchant Interchange Type</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_interchange_type', '' )}
											onChange={props.handleItemChange}
											validators={['required']}												
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'mm_interchange_type',
											id: 'mm_interchange_type',
											}}
										>
											{merchantTypeList}
										</SelectField>
									</Col>
									
								</Row>
							</Form.Group>	
							<Form.Group className="col-md-12">
								<Row>
									<Col md={4} >
										<label>Have Merchants or Owners/Principals Ever Filed for Bankruptcy</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Extra, 'me_bankruptcy', '' )}
											onChange={props.handleItemChange}
											validators={['required']}												
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'me_bankruptcy',
											id: 'me_bankruptcy',
											}}
										>
											{yesNoList}
										</SelectField>
									</Col>
									<Col md={4}>
										<label>Ownership Type</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Extra, 'me_ownership_type', '' )}
											onChange={props.handleItemChange}
											validators={['required']}												
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'me_ownership_type',
											id: 'me_ownership_type',
											}}
										>
											{ownershipList}
										</SelectField>
									</Col>
									 
								</Row>
							</Form.Group>
							 																									
								
							<Form.Group className='col-md-12'>
								<Row>
									<Col>CORPORATE/LEGAL ADDRESS</Col>
								</Row>
							</Form.Group>
							 
							<Form.Group className='col-md-12'>
								<Row>
									<Col md={5} >
										<label>City</label>
										<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_mail_city', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_mail_city',
											id: 'mm_mail_city',
											placeholder: 'CITY',
											type: 'text',
											classselector: "h-auto"
										}}
										/>
						
									</Col>
									<Col md={4}>
										<label>State</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_mail_state', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'mm_mail_state',
											id: 'mm_mail_state',
											}}
										>
											{stateList}
										</SelectField>
											
						
									</Col>	
									<Col md={3} >
										<label>State</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_mail_zip', '' )}
											onChange={props.handleItemChange}
											validators={['required']}											
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_mail_zip',
												id: 'mm_mail_zip',
												placeholder: 'ZIPCODE',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>	
								</Row>
							</Form.Group>

							<Form.Group className='col-md-12'>
								<Row>
									<Col>BILLING ADDRESS</Col>
								</Row>
							</Form.Group>
							<Form.Group className='col-md-12'>
								<Row>
									<Col md={6} >
										<label >Street</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_billing_address', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_billing_address',
												id: 'mm_billing_address',
												placeholder: 'STREET ADDRESS',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>
									<Col md={6} >
										<label >Street 2</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_billing_address_2', '' )}
											onChange={props.handleItemChange}
											validators={['required']}
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_billing_address_2',
												id: 'mm_billing_address_2',
												placeholder: 'STREET ADDRESS 2',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>
								</Row>
							</Form.Group>
							<Form.Group className='col-md-12'>
								<Row>
									<Col md={5} >
										<label>City</label>
										<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_billing_city', '' )}
										onChange={props.handleItemChange}
										validators={['required']}
										errorMessages={["REQUIRED"]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'mm_billing_city',
											id: 'mm_billing_city',
											placeholder: 'CITY',
											type: 'text',
											classselector: "h-auto"
										}}
										/>
						
									</Col>
									<Col md={4}>
										<label>State</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_billing_state', '' )}
											onChange={props.handleItemChange}
											validators={['required']}											
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'mm_billing_state',
											id: 'mm_billing_state',
											}}
										>
											{stateList}
										</SelectField>
											
						
									</Col>	
									<Col md={3} >
										<label>State</label>
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'mm_billing_zip', '' )}
											onChange={props.handleItemChange}
											validators={['required']}											
											errorMessages={["REQUIRED"]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'mm_billing_zip',
												id: 'mm_billing_zip',
												placeholder: 'ZIPCODE',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
						
									</Col>	
								</Row>
							</Form.Group>
						</Row>
					 
					
					<div className="row">
						<Col md="9"></Col>
						<Col md="3">
							<Button variant="contained" color="primary" type="button" onClick={() => props.performSubmit()}  className="col-md-12"> Save &amp; Continue </Button>
						</Col>
					</div>
					</ValidatorForm>
					
						
					
				</div>
					
				
					
					 
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</div>
  );
}

GetMerchantAddStep1.propTypes = {
  displayWarning: PropTypes.func,
};

export default GetMerchantAddStep1;

