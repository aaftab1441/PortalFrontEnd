import React from 'react';
import PropTypes from 'prop-types';
import { ValidatorForm } from 'react-material-ui-form-validator';
import TextBox from '../../common/TextBox';
import SelectField from '../../common/SelectField';

import * as AppConstants from '../../../utilities/constants';
import * as StringUtils from '../../../utilities/string';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Paper from '@mui/material/Paper';
import DataTable from 'react-data-table-component';
import { Row, Col,Form} from 'react-bootstrap'; 
import { Button } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import { Theme, createStyles, makeStyles } from '@mui/system';
import MenuItem from '@mui/material/MenuItem';
import DatePicker from "react-datepicker";
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
//import Button from '@mui/material/Button';
// import styled from 'styled-components';
 

function GetMerchantAddStep6(props) {
  let documentTypeList = [];
  let count = 0;
  let startCount = 0;

  //const classes = useStyles();
  console.log("Merchant List", props);
  
  let documents  = [];
  let appMessages = StringUtils.getDisplayMessages(props.messages);
  let yesNoList = []
  let mailingPreferenceList = [];
  let fees = "";
   
  if(props.lists &&  props.lists.STATUS){
	  
	documentTypeList = props.lists.DOCUMENT_TYPE_LIST.map(function (anItem, index) {
		return <MenuItem value={anItem.code} key={index}>{anItem.value}</MenuItem>;
	  });
	  
	  
	}

  return (
		<div>
		  <div className="row">
			<div className="col-lg-12">
			  <div className="card">
				<div className="card-body">
				  <div className="row">
					<div className="col-12" id="search">
						<h4>DOCUMENT(S) UPLOAD</h4>
						<Stepper activeStep={5} alternativeLabel>

							<Step key={'General_Information'}>
								<StepLabel>General Information</StepLabel>
							</Step>
							<Step key={'Fee_Disc'}>
								<StepLabel>Fee/Disc</StepLabel>
							</Step>
							<Step key={'ISO'}>
								<StepLabel>ISO</StepLabel>
							</Step>
							<Step key={'Merchant_Management'}>
								<StepLabel>Merchant Management</StepLabel>
							</Step>
							<Step key={'Merchant_Owner'}>
								<StepLabel>Merchant Owner</StepLabel>
							</Step>
							<Step key={'Document_Upload'}>
								<StepLabel>Document(s) Upload</StepLabel>
							</Step>

						</Stepper>
					<ValidatorForm className="pt-3" onSubmit={(data) => props.doSearch(data, props.user, props.lists)}>
						 
							
						<Row>
							 
							<Col>DOCUMENTS</Col>
							<br /><br />
							 
						</Row>
						 
								
						<Form.Group className='col-md-12'> 
							<Row>
								<Col md={4} >
									<label>Document Type</label>
									<SelectField
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'document_type', '' )}
										onChange={props.handleItemChange}
										validators={['required']}											
										variant="outlined" size="small"
										errorMessages={['Required']}
										inputProps={{
										name: 'document_type',
										id: 'document_type', 
										}}
									>
										{documentTypeList}
									</SelectField>
								</Col>
								<Col md={4}>
									<label>Document</label>
									<TextBox
										value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'upload_document', '' )}
										onChange={props.handleItemChange}
										validators={[]}
										errorMessages={[]}
										variant={'outlined'} size="small"
										inputProps={{
											name: 'upload_document',
											id: 'upload_document',
											placeholder: 'DOCUMENT',
											type: 'file',
											classselector: "h-auto"
										}}
									/>
								</Col>									
								<Col md={4}>
									<label>&nbsp;</label>
									<Button variant="contained" color="primary" type="button"  onClick={() => props.performSubmit()} className="col-md-12"> Upload </Button>
								</Col>	
							</Row>									
						</Form.Group>
						<Form.Group className='col-md-12'> 
							<Row>
							   
							   <Col>UPLOADED DOCUMENTS</Col>
							   <br /><br />
								
						   </Row>  
						   <Row>
								<Form.Group className='col-md-12'>
										<TableContainer component={Paper} style={{maxHeight: 400, overflow: 'auto'}}>
										<Table >
										   <TableHead>
											   <TableRow>
											   <TableCell >&nbsp;</TableCell >											  
											   <TableCell >Document Type</TableCell >
											   <TableCell >File Name</TableCell >
											   <TableCell >Action</TableCell >
											 </TableRow>
												
										   </TableHead>
										   <TableBody>
											   {documents}
										   </TableBody>
   
										</Table >
										
								   </TableContainer>
							   </Form.Group>
									
							</Row>									
						</Form.Group>
						 
					
						<div className="row">
							<Col md="3">
								<Button variant="contained" color="primary" type="button" onClick={() => props.performReturn()} className="col-md-12"> Return </Button>
							</Col>
							<Col md="6">&nbsp;</Col>
							<Col md="3">
								<Button variant="contained" color="primary" type="button"  onClick={() => props.performSubmit()} className="col-md-12"> Save &amp; Continue </Button>
							</Col>
							
						</div>
					</ValidatorForm>
					
						
					
				</div>
					
				
					
					 
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</div>
  );
}

GetMerchantAddStep6.propTypes = {
  displayWarning: PropTypes.func,
};

export default GetMerchantAddStep6;

