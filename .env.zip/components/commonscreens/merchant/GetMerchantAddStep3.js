import React from 'react';
import PropTypes from 'prop-types';
import { ValidatorForm } from 'react-material-ui-form-validator';
import TextBox from '../../common/TextBox';
import SelectField from '../../common/SelectField';

import * as AppConstants from '../../../utilities/constants';
import * as StringUtils from '../../../utilities/string';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Paper from '@mui/material/Paper';
import DataTable from 'react-data-table-component';
import { Row, Col,Form} from 'react-bootstrap'; 
import { Button } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import { Theme, createStyles, makeStyles } from '@mui/system';
import MenuItem from '@mui/material/MenuItem';
import DatePicker from "react-datepicker";
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
//import Button from '@mui/material/Button';
// import styled from 'styled-components';
 

function GetMerchantAddStep3(props) {
  let stateList = [];
  let count = 0;
  let startCount = 0;

  //const classes = useStyles();
  console.log("Merchant List", props);
  
  let irsTaxList  = [];
  let appMessages = StringUtils.getDisplayMessages(props.messages);
  let isoList  = [];
  let ownershipList = []
  let mailingPreferenceList = [];
  let fees = "";
   
  if(props.lists &&  props.lists.STATUS){
	isoList = props.lists.ISO_LIST.map(function (anItem, index) {
		return <MenuItem value={anItem.ISO_CODE} key={index}>{anItem.ISO_CODE} - {anItem.ISO_NAME}</MenuItem>;
	  });
	}

  return (
		<div>
		  <div className="row">
			<div className="col-lg-12">
			  <div className="card">
				<div className="card-body">
				  <div className="row">
					<div className="col-12" id="search">
						<h4>ISO INFORMATION</h4>
						<Stepper activeStep={2} alternativeLabel>

							<Step key={'General_Information'}>
								<StepLabel>General Information</StepLabel>
							</Step>
							<Step key={'Fee_Disc'}>
								<StepLabel>Fee/Disc</StepLabel>
							</Step>
							<Step key={'ISO'}>
								<StepLabel>ISO</StepLabel>
							</Step>
							<Step key={'Merchant_Management'}>
								<StepLabel>Merchant Management</StepLabel>
							</Step>
							<Step key={'Merchant_Owner'}>
								<StepLabel>Merchant Owner</StepLabel>
							</Step>
							<Step key={'Document_Upload'}>
								<StepLabel>Document(s) Upload</StepLabel>
							</Step>

						</Stepper>
					<ValidatorForm className="pt-3" onSubmit={(data) => props.doSearch(data, props.user, props.lists)}>
						 
							
						<Row>
							 
							<Col>ISO INFORMATION</Col>
							<br /><br />
							 
						</Row>
						 
								
						<Row>
							<Form.Group className="col-md-12">
								<Row>
									<Col md={12}>
										<label>ISO - Office Name and Code</label>
										<SelectField
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'iso', '' )}
											onChange={props.handleItemChange}
											validators={['required']}												
											variant="outlined" size="small"
											errorMessages={['Required']}
											inputProps={{
											name: 'iso',
											id: 'iso',
											}}
										>
											{isoList}
										</SelectField>
									</Col>
								</Row>
							</Form.Group>
							<Form.Group className="col-md-12">	
								<Row>
									<Col md={12}>
										<label>Sub ISO</label>								
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'sub_iso', '' )}
											onChange={props.handleItemChange}
											validators={[]}
											errorMessages={[]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'sub_iso',
												id: 'sub_iso',
												placeholder: 'SUB ISO',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
									</Col>
									
								</Row>
							</Form.Group>
							<Form.Group className="col-md-12">	

								<Row>
									<Col md={12}>
										<label>Sales Office</label>								
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'sales_office', '' )}
											onChange={props.handleItemChange}
											validators={[]}
											errorMessages={[]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'sales_office',
												id: 'sales_office',
												placeholder: 'SALES OFFICE',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
									</Col>
									
								</Row>
							</Form.Group>
							<Form.Group className="col-md-12">	

								<Row>
									<Col md={12}>
										<label>Sales Rep</label>								
										<TextBox
											value={StringUtils.getObjectValue(props.addMerchant.Merchant, 'sales_agent', '' )}
											onChange={props.handleItemChange}
											validators={[]}
											errorMessages={[]}
											variant={'outlined'} size="small"
											inputProps={{
												name: 'sales_agent',
												id: 'sales_agent',
												placeholder: 'SALES REP',
												type: 'text',
												classselector: "h-auto"
											}}
										/>
									</Col>
									
								</Row>																
							</Form.Group>
						</Row>
					
						<div className="row">
							<Col md="3">
								<Button variant="contained" color="primary" type="button" onClick={() => props.performReturn()} className="col-md-12"> Return </Button>
							</Col>
							<Col md="6">&nbsp;</Col>
							<Col md="3">
								<Button variant="contained" color="primary" type="button"  onClick={() => props.performSubmit()} className="col-md-12"> Save &amp; Continue </Button>
							</Col>
							
						</div>
					</ValidatorForm>
					
						
					
				</div>
					
				
					
					 
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</div>
  );
}

GetMerchantAddStep3.propTypes = {
  displayWarning: PropTypes.func,
};

export default GetMerchantAddStep3;

