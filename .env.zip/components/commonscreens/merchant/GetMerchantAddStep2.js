import React from 'react';
import PropTypes from 'prop-types';
import { ValidatorForm } from 'react-material-ui-form-validator';
import TextBox from '../../common/TextBox';
import SelectField from '../../common/SelectField';

import * as AppConstants from '../../../utilities/constants';
import * as StringUtils from '../../../utilities/string';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Paper from '@mui/material/Paper';
import DataTable from 'react-data-table-component';
import { Row, Col,Form} from 'react-bootstrap'; 
import { Button } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import { Theme, createStyles, makeStyles } from '@mui/system';
import MenuItem from '@mui/material/MenuItem';
import DatePicker from "react-datepicker";
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
//import Button from '@mui/material/Button';
// import styled from 'styled-components';
 

function GetMerchantAddStep2(props) {
	let stateList = [];
	let count = 0;
	let startCount = 0;
  
	//const classes = useStyles();
	console.log("Merchant List", props);
	
	let irsTaxList  = [];
	let statusList  = [];
	 
	const fees = props.fees.map( (anItem, index) => 
		   <TableRow key={index}>
			  <TableCell><Button variant="contained" color="primary" type="button" onClick={() => props.addFee(anItem)} className="col-md-12"> Assign </Button></TableCell>
			 
			  <TableCell>{anItem.Fee_Description}</TableCell>
			  <TableCell>{anItem.Fee_Frequency} </TableCell>
			  <TableCell>{anItem.Fee_Trans_Type}</TableCell>
			  <TableCell>{anItem.Fee_Apply_Value_As}</TableCell>
			  <TableCell>{anItem.Fee_Value}</TableCell>
		  </TableRow>
		);
   	let assignedFeeKeys = [];
	   if(assignedFeeKeys){
		assignedFeeKeys = Object.keys(props.addMerchant.assignedFees);   
	   }
	const assignedFees = assignedFeeKeys.map( function(feeKey, index) {
		let anItem = props.addMerchant.assignedFees[feeKey];
		return <TableRow key={index}>
		   <TableCell><Button variant="contained" color="primary" type="button" onClick={() => props.removeFee(anItem)} className="col-md-12"> Remove </Button></TableCell>		  
		   <TableCell>{anItem.Fee_Description}</TableCell>
		   <TableCell>{anItem.Fee_Frequency} </TableCell>
		   <TableCell>{anItem.Fee_Trans_Type}</TableCell>
		   <TableCell>{anItem.Fee_Apply_Value_As}</TableCell>
		   <TableCell>
			   <TextBox
				value={anItem.Fee_Value}
				onChange={props.handleFeeItemChange}
				validators={[]}
				errorMessages={[]}
				variant={'outlined'}
				inputProps={{
					name: anItem.Fee_Code,
					id: anItem.Fee_Code,
					placeholder: anItem.Fee_Description,
					type: 'text',
					classselector: "h-auto"
				}}
			/></TableCell>
	   </TableRow>
	});


	if(props.lists &&  props.lists.STATUS){
	  statusList = props.lists.STATUS.map(function (anItem, index) {
		  return <MenuItem value={anItem.code} key={index}>{anItem.value}</MenuItem>;
		});
	  }
  console.log("Fees", fees, props.fees);
	return (
		  <div>
			<div className="row">
			  <div className="col-lg-12">
				<div className="card">
				  <div className="card-body">
					<div className="row">
					  <div className="col-12" id="search">
						  <h4>Merchant Add</h4>
						  <Stepper activeStep={1} alternativeLabel>
  
							  <Step key={'General_Information'}>
								  <StepLabel>General Information</StepLabel>
							  </Step>
							  <Step key={'Fee_Disc'}>
								  <StepLabel>Fee/Disc</StepLabel>
							  </Step>
							  <Step key={'ISO'}>
								  <StepLabel>ISO</StepLabel>
							  </Step>
							  <Step key={'Merchant_Management'}>
								  <StepLabel>Merchant Management</StepLabel>
							  </Step>
							  <Step key={'Merchant_Owner'}>
								  <StepLabel>Merchant Owner</StepLabel>
							  </Step>
							  <Step key={'Document_Upload'}>
								  <StepLabel>Document(s) Upload</StepLabel>
							  </Step>
  
						  </Stepper>
					  <ValidatorForm className="pt-3" onSubmit={(data) => props.doSearch(data, props.user, props.lists)}>
						   
							  
						  <Row>
							   
							  <Col>FEES</Col>
							  <br /><br />
							   
						  </Row>  
						  <Row>
							   <Form.Group className='col-md-12'>
							   		<TableContainer component={Paper} style={{maxHeight: 400, overflow: 'auto'}}>
									   <Table >
										  <TableHead>
										  	<TableRow>
											  <TableCell >&nbsp;</TableCell >											  
											  <TableCell >Fee Description</TableCell >
											  <TableCell >Fee Frequency</TableCell >
											  <TableCell >Fee Trans Type</TableCell >
											  <TableCell >Fee Apply Value As</TableCell >
											  <TableCell >Fee Fee Value</TableCell >
											</TableRow>
											   
										  </TableHead>
										  <TableBody>
											  {fees}
										  </TableBody>
  
									   </Table >
									   
								  </TableContainer>
							  </Form.Group>
								   
						   </Row>
					   
					   	  
						   <Row>
							   
							   <Col>ASSIGNED FEES</Col>
							   <br /><br />
								
						   </Row>  
						   <Row>
								<Form.Group className='col-md-12'>
										<TableContainer component={Paper} style={{maxHeight: 400, overflow: 'auto'}}>
										<Table >
										   <TableHead>
											   <TableRow>
											   <TableCell >&nbsp;</TableCell >											  
											   <TableCell >Fee Description</TableCell >
											   <TableCell >Fee Frequency</TableCell >
											   <TableCell >Fee Trans Type</TableCell >
											   <TableCell >Fee Apply Value As</TableCell >
											   <TableCell >Fee Fee Value</TableCell >
											 </TableRow>
												
										   </TableHead>
										   <TableBody>
											   {assignedFees}
										   </TableBody>
   
										</Table >
										
								   </TableContainer>
							   </Form.Group>
									
							</Row>
					  
						  <div className="row">
							  <Col md="3">
								  <Button variant="contained" color="primary" type="button" onClick={() => props.performReturn()} className="col-md-12"> Return </Button>
							  </Col>
							  <Col md="6">&nbsp;</Col>
							  <Col md="3">
								  <Button variant="contained" color="primary" type="button"  onClick={() => props.performSubmit()} className="col-md-12"> Save &amp; Continue </Button>
							  </Col>
							  
						  </div>
					  </ValidatorForm>
					  
						  
					  
				  </div>
					  
				  
					  
					   
					</div>
				  </div>
				</div>
			  </div>
			</div>
		  </div>
	);
}

GetMerchantAddStep2.propTypes = {
  displayWarning: PropTypes.func,
};

export default GetMerchantAddStep2;

